"""
Task 22 — Airflow Basics: Create DAG for ETL pipeline
Task 23 — Airflow Advanced: Scheduling, monitoring, retry mechanisms
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.utils.trigger_rule import TriggerRule
import logging

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# DEFAULT ARGS  (Task 23: retry + monitoring)
# ─────────────────────────────────────────────
default_args = {
    "owner": "ipl_data_engineer",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 3,                             # Task 23: retry mechanism
    "retry_delay": timedelta(minutes=5),      # Task 23: retry delay
    "execution_timeout": timedelta(hours=1),
    "start_date": datetime(2024, 1, 1),
}

# ─────────────────────────────────────────────
# PYTHON CALLABLES
# ─────────────────────────────────────────────

def task_generate_data():
    import subprocess, sys
    result = subprocess.run(
        [sys.executable, "scripts/generate_data.py"],
        capture_output=True, text=True
    )
    logger.info(result.stdout)
    if result.returncode != 0:
        raise RuntimeError(f"Data generation failed: {result.stderr}")

def task_run_etl():
    import sys, os
    sys.path.insert(0, os.getcwd())
    from scripts.etl_pipeline import run_etl
    run_etl()

def task_run_analytics():
    import sys, os
    sys.path.insert(0, os.getcwd())
    from scripts.sql_analytics import run_all_analytics
    run_all_analytics()

def task_run_quality_check():
    import sqlite3
    conn = sqlite3.connect("data/warehouse/ipl_warehouse.db")
    cursor = conn.cursor()

    checks = {
        "matches_not_empty": "SELECT COUNT(*) FROM fact_matches",
        "batting_not_empty":  "SELECT COUNT(*) FROM fact_batting",
        "bowling_not_empty":  "SELECT COUNT(*) FROM fact_bowling",
        "no_null_winners":    "SELECT COUNT(*) FROM fact_matches WHERE winner IS NULL",
    }

    for check_name, query in checks.items():
        count = cursor.execute(query).fetchone()[0]
        if "null" in check_name and count > 0:
            raise ValueError(f"Quality check FAILED: {check_name} returned {count}")
        elif "not_empty" in check_name and count == 0:
            raise ValueError(f"Quality check FAILED: {check_name} — table is empty")
        else:
            logger.info(f"✅ Quality check passed: {check_name} = {count}")

    conn.close()

def task_generate_dashboard():
    import sys, os
    sys.path.insert(0, os.getcwd())
    from dashboard.dashboard import generate_dashboard
    generate_dashboard()

def task_notify_success(**context):
    exec_date = context.get("execution_date", datetime.now())
    logger.info(f"✅ IPL Pipeline completed successfully for execution: {exec_date}")
    logger.info("Summary: Data generated → ETL complete → Quality OK → Dashboard updated")

# ─────────────────────────────────────────────
# DAG DEFINITION  (Task 22 & 23)
# ─────────────────────────────────────────────

with DAG(
    dag_id="ipl_data_pipeline",
    description="End-to-end IPL Cricket Analytics Data Engineering Pipeline",
    default_args=default_args,
    schedule_interval="0 6 * * *",       # Task 23: daily at 6 AM
    catchup=False,
    max_active_runs=1,
    tags=["ipl", "data-engineering", "capstone"],
) as dag:

    # Task 1: Data Ingestion
    t_generate = PythonOperator(
        task_id="generate_raw_data",
        python_callable=task_generate_data,
        doc_md="Generates synthetic IPL CSV data simulating real-world ingestion."
    )

    # Task 2: ETL
    t_etl = PythonOperator(
        task_id="run_etl_pipeline",
        python_callable=task_run_etl,
        doc_md="Extract → Transform (clean, validate, normalize) → Load into SQLite warehouse."
    )

    # Task 3: SQL Analytics
    t_analytics = PythonOperator(
        task_id="run_sql_analytics",
        python_callable=task_run_analytics,
        doc_md="Run SQL queries: basic + advanced (window functions, subqueries)."
    )

    # Task 4: Data Quality (Task 23: monitoring)
    t_quality = PythonOperator(
        task_id="data_quality_checks",
        python_callable=task_run_quality_check,
        retries=2,
        doc_md="Validates data integrity and quality in the warehouse."
    )

    # Task 5: Dashboard
    t_dashboard = PythonOperator(
        task_id="generate_dashboard",
        python_callable=task_generate_dashboard,
        doc_md="Generates HTML dashboard with charts and KPIs."
    )

    # Task 6: Notify (Task 23: monitoring notification)
    t_notify = PythonOperator(
        task_id="notify_success",
        python_callable=task_notify_success,
        provide_context=True,
        trigger_rule=TriggerRule.ALL_SUCCESS,
        doc_md="Logs pipeline success notification."
    )

    # Task 7: Cleanup old logs (Task 1 — Linux shell script)
    t_cleanup = BashOperator(
        task_id="cleanup_old_logs",
        bash_command="find logs/ -name '*.log' -mtime +7 -delete && echo 'Old logs cleaned'",
        trigger_rule=TriggerRule.ALL_DONE,
    )

    # ── Pipeline DAG Dependencies ──
    t_generate >> t_etl >> t_analytics >> t_quality >> t_dashboard >> t_notify >> t_cleanup
