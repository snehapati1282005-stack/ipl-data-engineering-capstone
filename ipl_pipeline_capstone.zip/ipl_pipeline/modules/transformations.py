"""
Task 4 — Advanced Python: Reusable Modules for Data Transformation
Normalization, aggregation, validation functions used across the pipeline.
"""

import pandas as pd
import numpy as np
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# VALIDATION
# ─────────────────────────────────────────────

def validate_schema(df: pd.DataFrame, required_columns: list, name: str = "DataFrame") -> bool:
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        logger.error(f"[{name}] Missing columns: {missing}")
        return False
    logger.info(f"[{name}] Schema validation passed. Shape: {df.shape}")
    return True


def validate_no_duplicates(df: pd.DataFrame, subset: list, name: str = "DataFrame") -> pd.DataFrame:
    dupes = df.duplicated(subset=subset).sum()
    if dupes > 0:
        logger.warning(f"[{name}] Found {dupes} duplicate rows on {subset}. Dropping...")
        df = df.drop_duplicates(subset=subset)
    return df


def validate_ranges(df: pd.DataFrame, column: str, min_val, max_val, name: str = "") -> pd.DataFrame:
    out_of_range = df[(df[column] < min_val) | (df[column] > max_val)]
    if len(out_of_range) > 0:
        logger.warning(f"[{name}] {len(out_of_range)} rows out of range for column '{column}'. Filtering...")
        df = df[(df[column] >= min_val) & (df[column] <= max_val)]
    return df


# ─────────────────────────────────────────────
# CLEANING
# ─────────────────────────────────────────────

def clean_missing(df: pd.DataFrame, strategy: dict) -> pd.DataFrame:
    """
    strategy: {column_name: fill_value or 'drop' or 'median' or 'mean'}
    """
    for col, method in strategy.items():
        if col not in df.columns:
            continue
        missing_count = df[col].isnull().sum()
        if missing_count == 0:
            continue
        if method == "drop":
            df = df.dropna(subset=[col])
            logger.info(f"Dropped {missing_count} rows with null '{col}'")
        elif method == "median":
            df[col] = df[col].fillna(df[col].median())
            logger.info(f"Filled {missing_count} nulls in '{col}' with median")
        elif method == "mean":
            df[col] = df[col].fillna(df[col].mean())
            logger.info(f"Filled {missing_count} nulls in '{col}' with mean")
        else:
            df[col] = df[col].fillna(method)
            logger.info(f"Filled {missing_count} nulls in '{col}' with '{method}'")
    return df


# ─────────────────────────────────────────────
# NORMALIZATION
# ─────────────────────────────────────────────

def normalize_min_max(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    for col in columns:
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            col_min, col_max = df[col].min(), df[col].max()
            if col_max != col_min:
                df[f"{col}_normalized"] = (df[col] - col_min) / (col_max - col_min)
    return df


def normalize_z_score(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    for col in columns:
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            df[f"{col}_zscore"] = (df[col] - df[col].mean()) / df[col].std()
    return df


# ─────────────────────────────────────────────
# AGGREGATION
# ─────────────────────────────────────────────

def aggregate_team_stats(matches_df: pd.DataFrame) -> pd.DataFrame:
    wins = matches_df.groupby("winner").size().reset_index(name="wins")
    team1_played = matches_df.groupby("team1").size().reset_index(name="t1")
    team2_played = matches_df.groupby("team2").size().reset_index(name="t2")
    team1_played.columns = ["team", "t1"]
    team2_played.columns = ["team", "t2"]
    played = team1_played.merge(team2_played, on="team", how="outer").fillna(0)
    played["total_matches"] = played["t1"] + played["t2"]
    wins.columns = ["team", "wins"]
    stats = played.merge(wins, on="team", how="left").fillna(0)
    stats["win_rate"] = (stats["wins"] / stats["total_matches"] * 100).round(2)
    return stats.sort_values("wins", ascending=False)


def aggregate_player_batting(batting_df: pd.DataFrame) -> pd.DataFrame:
    return batting_df.groupby("player").agg(
        total_runs=("runs", "sum"),
        matches=("match_id", "nunique"),
        avg_runs=("runs", "mean"),
        avg_strike_rate=("strike_rate", "mean"),
        total_fours=("fours", "sum"),
        total_sixes=("sixes", "sum")
    ).reset_index().round(2).sort_values("total_runs", ascending=False)


def aggregate_player_bowling(bowling_df: pd.DataFrame) -> pd.DataFrame:
    return bowling_df.groupby("bowler").agg(
        total_wickets=("wickets", "sum"),
        matches=("match_id", "nunique"),
        avg_economy=("economy", "mean"),
        total_overs=("overs", "sum"),
        total_runs_given=("runs_given", "sum")
    ).reset_index().round(2).sort_values("total_wickets", ascending=False)
