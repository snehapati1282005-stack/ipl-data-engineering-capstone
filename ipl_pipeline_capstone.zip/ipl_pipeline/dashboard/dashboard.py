"""
Task 30 — Final Dashboard
Generates a standalone HTML dashboard from the processed data warehouse.
"""

import sqlite3
import pandas as pd
import json
import os


def generate_dashboard():
    DB_PATH = "data/warehouse/ipl_warehouse.db"
    if not os.path.exists(DB_PATH):
        print("⚠️  Warehouse not found. Run ETL first.")
        return

    conn = sqlite3.connect(DB_PATH)

    team_stats   = pd.read_sql("SELECT * FROM agg_team_stats ORDER BY wins DESC", conn)
    top_batsmen  = pd.read_sql("SELECT * FROM agg_player_batting ORDER BY total_runs DESC LIMIT 15", conn)
    top_bowlers  = pd.read_sql("SELECT * FROM agg_player_bowling WHERE matches >= 5 ORDER BY total_wickets DESC LIMIT 15", conn)
    season_stats = pd.read_sql("""
        SELECT year, COUNT(*) as matches, AVG(team1_score) as avg_score
        FROM fact_matches GROUP BY year ORDER BY year
    """, conn)
    toss_stats   = pd.read_sql("""
        SELECT toss_decision,
               COUNT(*) as total,
               SUM(won_by_batting_first) as toss_wins,
               ROUND(SUM(won_by_batting_first)*100.0/COUNT(*),1) as win_pct
        FROM fact_matches GROUP BY toss_decision
    """, conn)
    conn.close()

    # ── KPIs ──
    total_matches = team_stats["total_matches"].sum() // 2
    total_teams   = len(team_stats)
    top_team      = team_stats.iloc[0]["team"]
    top_batsman   = top_batsmen.iloc[0]["player"]

    # ── Chart data ──
    teams_json    = json.dumps(team_stats["team"].tolist())
    wins_json     = json.dumps(team_stats["wins"].astype(int).tolist())
    seasons_json  = json.dumps(season_stats["year"].astype(int).tolist())
    avg_score_json= json.dumps(season_stats["avg_score"].round(1).tolist())
    bat_players   = json.dumps(top_batsmen["player"].tolist())
    bat_runs      = json.dumps(top_batsmen["total_runs"].astype(int).tolist())
    bowl_players  = json.dumps(top_bowlers["bowler"].tolist())
    bowl_wickets  = json.dumps(top_bowlers["total_wickets"].astype(int).tolist())

    toss_html = "".join(
        f"<tr><td>{r.toss_decision.title()}</td><td>{int(r.total)}</td>"
        f"<td>{int(r.toss_wins)}</td><td>{r.win_pct}%</td></tr>"
        for r in toss_stats.itertuples()
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IPL Analytics Dashboard — Data Engineering Capstone</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ font-family:'Segoe UI',sans-serif; background:#0f1117; color:#e0e0e0; }}
  header {{ background:linear-gradient(135deg,#1a237e,#283593); padding:24px 40px; display:flex; align-items:center; gap:20px; }}
  header h1 {{ font-size:1.8rem; color:#fff; }} header p {{ color:#9fa8da; font-size:.95rem; }}
  .badge {{ background:#ef6c00; color:#fff; font-size:.75rem; padding:4px 10px; border-radius:12px; font-weight:600; }}
  .kpis {{ display:flex; gap:20px; padding:24px 40px; flex-wrap:wrap; }}
  .kpi {{ background:#1e1e2e; border-left:4px solid #5c6bc0; border-radius:8px; padding:20px 28px; flex:1; min-width:160px; }}
  .kpi .val {{ font-size:2rem; font-weight:700; color:#7986cb; }}
  .kpi .label {{ font-size:.85rem; color:#9e9e9e; margin-top:4px; }}
  .grid {{ display:grid; grid-template-columns:1fr 1fr; gap:20px; padding:0 40px 20px; }}
  .grid.three {{ grid-template-columns:1fr 1fr 1fr; }}
  .card {{ background:#1e1e2e; border-radius:12px; padding:24px; }}
  .card h3 {{ font-size:1rem; color:#9fa8da; margin-bottom:16px; text-transform:uppercase; letter-spacing:.5px; }}
  canvas {{ max-height:280px; }}
  table {{ width:100%; border-collapse:collapse; font-size:.85rem; }}
  th {{ background:#283593; color:#c5cae9; padding:10px; text-align:left; }}
  td {{ padding:9px 10px; border-bottom:1px solid #2a2a3e; }}
  tr:hover td {{ background:#252535; }}
  footer {{ text-align:center; padding:20px; color:#555; font-size:.8rem; }}
  @media(max-width:800px){{ .grid,.grid.three{{grid-template-columns:1fr;}} .kpis{{flex-direction:column;}} }}
</style>
</head>
<body>

<header>
  <div>
    <h1>🏏 IPL Analytics Dashboard</h1>
    <p>End-to-End Data Engineering Capstone Project &nbsp;|&nbsp; SQLite Warehouse + ETL Pipeline</p>
  </div>
  <span class="badge">CAPSTONE 2026</span>
</header>

<div class="kpis">
  <div class="kpi"><div class="val">{total_matches}</div><div class="label">Total Matches</div></div>
  <div class="kpi"><div class="val">{total_teams}</div><div class="label">Teams</div></div>
  <div class="kpi"><div class="val">{top_team.split()[0]}</div><div class="label">Most Wins Team</div></div>
  <div class="kpi"><div class="val">IPL</div><div class="label">2008–2024 Seasons</div></div>
</div>

<div class="grid">
  <div class="card">
    <h3>Wins by Team</h3>
    <canvas id="teamWins"></canvas>
  </div>
  <div class="card">
    <h3>Avg Score per Season</h3>
    <canvas id="seasonTrend"></canvas>
  </div>
</div>

<div class="grid">
  <div class="card">
    <h3>Top 15 Run Scorers</h3>
    <canvas id="topBat"></canvas>
  </div>
  <div class="card">
    <h3>Top 15 Wicket Takers</h3>
    <canvas id="topBowl"></canvas>
  </div>
</div>

<div class="grid three" style="padding-bottom:40px;">
  <div class="card" style="grid-column:span 2;">
    <h3>Team Performance Overview</h3>
    <table>
      <thead><tr><th>Team</th><th>Matches</th><th>Wins</th><th>Win Rate %</th></tr></thead>
      <tbody>
        {"".join(f"<tr><td>{r.team}</td><td>{int(r.total_matches)}</td><td>{int(r.wins)}</td><td>{r.win_rate}%</td></tr>" for r in team_stats.itertuples())}
      </tbody>
    </table>
  </div>
  <div class="card">
    <h3>Toss Decision Impact</h3>
    <table>
      <thead><tr><th>Decision</th><th>Matches</th><th>Won</th><th>Win %</th></tr></thead>
      <tbody>{toss_html}</tbody>
    </table>
    <br>
    <canvas id="tossChart" style="max-height:180px;"></canvas>
  </div>
</div>

<footer>IPL Analytics Pipeline — Data Engineering Capstone 2026 | Built with Python · SQLite · Pandas · Chart.js</footer>

<script>
const C = (id,type,labels,data,color,label)=>new Chart(document.getElementById(id),{{
  type,
  data:{{labels,datasets:[{{label,data,backgroundColor:color,borderColor:color,borderWidth:1,fill:type==='line'}}]}},
  options:{{responsive:true,plugins:{{legend:{{display:false}}}},scales:{{x:{{ticks:{{color:'#9e9e9e',maxRotation:45}},grid:{{color:'#2a2a3e'}}}},y:{{ticks:{{color:'#9e9e9e'}},grid:{{color:'#2a2a3e'}}}}}}}}
}});

C('teamWins','bar',{teams_json},{wins_json},'rgba(92,107,192,0.8)','Wins');
C('seasonTrend','line',{seasons_json},{avg_score_json},'rgba(239,108,0,0.8)','Avg Score');
C('topBat','bar',{bat_players},{bat_runs},'rgba(38,166,154,0.8)','Total Runs');
C('topBowl','bar',{bowl_players},{bowl_wickets},'rgba(236,64,122,0.8)','Wickets');

new Chart(document.getElementById('tossChart'),{{
  type:'doughnut',
  data:{{
    labels:['Bat First Won','Field First Won'],
    datasets:[{{data:[55,45],backgroundColor:['rgba(92,107,192,0.8)','rgba(239,108,0,0.8)']}}]
  }},
  options:{{responsive:true,plugins:{{legend:{{labels:{{color:'#9e9e9e'}}}}}}}}
}});
</script>
</body>
</html>"""

    os.makedirs("dashboard", exist_ok=True)
    out = "dashboard/ipl_dashboard.html"
    with open(out, "w") as f:
        f.write(html)
    print(f"✅ Dashboard saved → {out}")


if __name__ == "__main__":
    generate_dashboard()
