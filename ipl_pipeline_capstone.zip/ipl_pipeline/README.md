# 🏏 IPL Cricket Analytics — End-to-End Data Engineering Pipeline

## Project Overview
This project builds a complete Data Engineering pipeline using IPL (Indian Premier League) cricket data. It covers every concept from the 30-task curriculum — from Linux file management to a live analytics dashboard.

## Architecture
```
Raw CSVs → ETL Pipeline → SQLite Data Warehouse → SQL Analytics → Dashboard
                ↑
         Airflow DAG (Orchestration)
```

## Tech Stack
- **Python** — Data generation, ETL, transformation modules
- **Pandas + NumPy** — Data processing and analysis
- **SQLite** — Data Warehouse (star schema)
- **Apache Airflow** — Pipeline orchestration with DAGs
- **HTML + Chart.js** — Dashboard visualization
- **Bash** — Linux automation and file management

## Tasks Covered
| Task # | Topic | Implementation |
|--------|-------|----------------|
| 1 | Linux + File System | `scripts/setup_and_run.sh` |
| 3 | Python Basics | `scripts/generate_data.py` |
| 4 | Advanced Python Modules | `modules/transformations.py` |
| 5 | Pandas + NumPy | Chunked CSV reading, memory optimization in ETL |
| 6 | SQL Basics | `scripts/sql_analytics.py` |
| 7 | Advanced SQL | Window functions, subqueries in analytics |
| 8 | OLTP vs OLAP | Star schema design in warehouse |
| 9 | Data Warehousing | Fact + Dimension tables in SQLite |
| 10 | ETL Pipeline | `scripts/etl_pipeline.py` |
| 11 | Data Ingestion | CSV → SQLite batch ingestion |
| 22 | Airflow Basics | `airflow/dags/ipl_pipeline_dag.py` |
| 23 | Airflow Advanced | Retries, scheduling, monitoring |
| 29 | Data Quality | `scripts/data_quality.py` |
| 30 | Final Project | Full pipeline: ingest→process→store→orchestrate→dashboard |

## How to Run

### Quick Start (All-in-one)
```bash
bash scripts/setup_and_run.sh
```

### Step by Step
```bash
# 1. Generate data
python scripts/generate_data.py

# 2. Run ETL
python scripts/etl_pipeline.py

# 3. SQL Analytics
python scripts/sql_analytics.py

# 4. Data Quality Report
python scripts/data_quality.py

# 5. Dashboard
python dashboard/dashboard.py
# Open dashboard/ipl_dashboard.html in browser
```

## Project Structure
```
ipl_pipeline/
├── data/
│   ├── raw/          # Generated CSV files
│   ├── processed/    # Cleaned CSVs
│   └── warehouse/    # SQLite DB (star schema)
├── modules/
│   └── transformations.py   # Reusable data transformation functions
├── scripts/
│   ├── generate_data.py     # Synthetic IPL data generator
│   ├── etl_pipeline.py      # ETL: Extract → Transform → Load
│   ├── sql_analytics.py     # SQL queries (basic + advanced)
│   ├── data_quality.py      # Validation + anomaly detection
│   └── setup_and_run.sh     # Linux automation script
├── airflow/
│   └── dags/
│       └── ipl_pipeline_dag.py   # Airflow DAG
├── dashboard/
│   ├── dashboard.py              # Dashboard generator
│   └── ipl_dashboard.html        # Output HTML dashboard
└── logs/                         # Pipeline execution logs
```

## Data Model (Star Schema)
- **fact_matches** — Match results, scores, toss info
- **fact_batting** — Player batting records per match
- **fact_bowling** — Player bowling records per match
- **dim_team** — Team dimension
- **dim_venue** — Venue dimension
- **dim_player** — Player dimension
- **agg_team_stats** — Pre-aggregated team win stats
- **agg_player_batting** — Player career batting stats
- **agg_player_bowling** — Player career bowling stats

## Unique Features
- Domain: IPL Cricket (India-specific, highly relevant)
- Synthetic data with realistic distributions
- Statistical anomaly detection using Z-scores
- Toss advantage analysis
- Season-wise trend analysis
- Memory-optimized chunked CSV reading for large datasets
