"""
Task 29 — Data Quality: Validation checks and anomaly detection
"""

import sqlite3
import pandas as pd
import numpy as np
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

DB_PATH = "data/warehouse/ipl_warehouse.db"


def check_completeness(conn):
    """Check for missing/null values in key columns."""
    print("\n📋 COMPLETENESS CHECKS")
    checks = [
        ("fact_matches", "winner"),
        ("fact_matches", "venue"),
        ("fact_batting", "player"),
        ("fact_bowling", "bowler"),
    ]
    all_pass = True
    for table, col in checks:
        result = pd.read_sql(f"SELECT COUNT(*) as nulls FROM {table} WHERE {col} IS NULL", conn)
        null_count = result["nulls"].iloc[0]
        status = "✅ PASS" if null_count == 0 else f"⚠️  WARN ({null_count} nulls)"
        print(f"  {table}.{col}: {status}")
        if null_count > 100:
            all_pass = False
    return all_pass


def check_referential_integrity(conn):
    """Ensure every match_id in batting exists in matches."""
    print("\n🔗 REFERENTIAL INTEGRITY CHECKS")
    orphan_batting = pd.read_sql("""
        SELECT COUNT(*) as cnt FROM fact_batting b
        WHERE b.match_id NOT IN (SELECT match_id FROM fact_matches)
    """, conn)["cnt"].iloc[0]

    orphan_bowling = pd.read_sql("""
        SELECT COUNT(*) as cnt FROM fact_bowling b
        WHERE b.match_id NOT IN (SELECT match_id FROM fact_matches)
    """, conn)["cnt"].iloc[0]

    print(f"  Orphan batting records: {'✅ 0' if orphan_batting == 0 else f'❌ {orphan_batting}'}")
    print(f"  Orphan bowling records: {'✅ 0' if orphan_bowling == 0 else f'❌ {orphan_bowling}'}")
    return orphan_batting == 0 and orphan_bowling == 0


def detect_statistical_anomalies(conn):
    """Z-score based anomaly detection on batting runs."""
    print("\n🔍 STATISTICAL ANOMALY DETECTION (Z-score method)")
    batting = pd.read_sql("SELECT player, runs, match_id FROM fact_batting", conn)
    batting["zscore"] = (batting["runs"] - batting["runs"].mean()) / batting["runs"].std()
    anomalies = batting[batting["zscore"].abs() > 3]
    print(f"  Total batting records: {len(batting)}")
    print(f"  Anomalous records (|z|>3): {len(anomalies)}")
    if len(anomalies) > 0:
        print(f"  Sample anomalies:\n{anomalies.head(5).to_string(index=False)}")
    return anomalies


def check_business_rules(conn):
    """Domain-specific validation rules."""
    print("\n📏 BUSINESS RULE CHECKS")

    # A match can't have same team in team1 and team2
    same_team = pd.read_sql(
        "SELECT COUNT(*) as cnt FROM fact_matches WHERE team1 = team2", conn
    )["cnt"].iloc[0]
    print(f"  Same team in both sides: {'✅ None' if same_team == 0 else f'❌ {same_team} records'}")

    # Score should be > 0
    low_score = pd.read_sql(
        "SELECT COUNT(*) as cnt FROM fact_matches WHERE team1_score <= 0 OR team2_score <= 0", conn
    )["cnt"].iloc[0]
    print(f"  Invalid scores (<=0): {'✅ None' if low_score == 0 else f'❌ {low_score} records'}")

    # Winner must be one of the two teams
    invalid_winner = pd.read_sql("""
        SELECT COUNT(*) as cnt FROM fact_matches
        WHERE winner NOT IN (team1, team2)
    """, conn)["cnt"].iloc[0]
    print(f"  Winner not in match teams: {'✅ None' if invalid_winner == 0 else f'❌ {invalid_winner}'}")


def run_all_quality_checks():
    print("=" * 55)
    print("🏏 IPL Data Pipeline — Quality Report")
    print("=" * 55)

    conn = sqlite3.connect(DB_PATH)
    c1 = check_completeness(conn)
    c2 = check_referential_integrity(conn)
    anomalies = detect_statistical_anomalies(conn)
    check_business_rules(conn)
    conn.close()

    print("\n" + "=" * 55)
    overall = "✅ PASSED" if (c1 and c2) else "⚠️  WARNINGS FOUND"
    print(f"Overall Quality Status: {overall}")
    print(f"Anomalous records flagged: {len(anomalies)}")
    print("=" * 55)


if __name__ == "__main__":
    run_all_quality_checks()
