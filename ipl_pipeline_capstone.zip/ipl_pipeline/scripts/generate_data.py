"""
Task 3 & 5 — Python Basics + Pandas/NumPy
Generate synthetic IPL match data (simulates real-world CSV ingestion source)
"""

import pandas as pd
import numpy as np
import os
import random
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

TEAMS = [
    "Mumbai Indians", "Chennai Super Kings", "Royal Challengers Bangalore",
    "Kolkata Knight Riders", "Delhi Capitals", "Sunrisers Hyderabad",
    "Rajasthan Royals", "Punjab Kings", "Gujarat Titans", "Lucknow Super Giants"
]

VENUES = [
    "Wankhede Stadium", "Chepauk Stadium", "M. Chinnaswamy Stadium",
    "Eden Gardens", "Arun Jaitley Stadium", "Rajiv Gandhi Stadium",
    "Sawai Mansingh Stadium", "PCA Stadium", "Narendra Modi Stadium", "BRSABV Ekana"
]

PLAYERS = {team: [f"Player_{team[:3]}_{i}" for i in range(1, 12)] for team in TEAMS}

def generate_matches(n=500):
    rows = []
    base_date = datetime(2008, 4, 18)
    for i in range(n):
        team1, team2 = random.sample(TEAMS, 2)
        venue = random.choice(VENUES)
        date = base_date + timedelta(days=random.randint(0, 5500))
        team1_score = random.randint(120, 230)
        team2_score = random.randint(100, 220)
        winner = team1 if team1_score > team2_score else team2
        rows.append({
            "match_id": i + 1,
            "date": date.strftime("%Y-%m-%d"),
            "season": date.year,
            "team1": team1,
            "team2": team2,
            "venue": venue,
            "team1_score": team1_score,
            "team2_score": team2_score,
            "winner": winner,
            "margin": abs(team1_score - team2_score),
            "toss_winner": random.choice([team1, team2]),
            "toss_decision": random.choice(["bat", "field"]),
            "player_of_match": random.choice(PLAYERS[winner])
        })
    return pd.DataFrame(rows)

def generate_batting(matches_df):
    rows = []
    for _, match in matches_df.iterrows():
        for team in [match["team1"], match["team2"]]:
            players = PLAYERS[team]
            runs_pool = np.random.dirichlet(np.ones(11)) * (
                match["team1_score"] if team == match["team1"] else match["team2_score"]
            )
            for idx, player in enumerate(players):
                runs = int(runs_pool[idx])
                balls = max(1, runs + random.randint(-5, 20))
                rows.append({
                    "match_id": match["match_id"],
                    "team": team,
                    "player": player,
                    "runs": runs,
                    "balls": balls,
                    "fours": random.randint(0, max(0, runs // 8)),
                    "sixes": random.randint(0, max(0, runs // 15)),
                    "strike_rate": round((runs / balls) * 100, 2) if balls > 0 else 0.0,
                    "dismissed": random.choice([True, False])
                })
    return pd.DataFrame(rows)

def generate_bowling(matches_df):
    rows = []
    for _, match in matches_df.iterrows():
        for team in [match["team1"], match["team2"]]:
            bowlers = random.sample(PLAYERS[team], 5)
            for bowler in bowlers:
                overs = random.randint(1, 4)
                wickets = random.randint(0, 3)
                runs_given = random.randint(overs * 4, overs * 15)
                rows.append({
                    "match_id": match["match_id"],
                    "bowling_team": team,
                    "bowler": bowler,
                    "overs": overs,
                    "wickets": wickets,
                    "runs_given": runs_given,
                    "economy": round(runs_given / overs, 2) if overs > 0 else 0.0,
                    "no_balls": random.randint(0, 3),
                    "wides": random.randint(0, 5)
                })
    return pd.DataFrame(rows)

if __name__ == "__main__":
    os.makedirs("data/raw", exist_ok=True)

    print("Generating matches data...")
    matches = generate_matches(500)
    # Introduce some missing values to simulate real-world data
    matches.loc[matches.sample(frac=0.02).index, "player_of_match"] = None
    matches.to_csv("data/raw/matches.csv", index=False)
    print(f"  → {len(matches)} matches saved to data/raw/matches.csv")

    print("Generating batting data...")
    batting = generate_batting(matches)
    batting.loc[batting.sample(frac=0.01).index, "strike_rate"] = None
    batting.to_csv("data/raw/batting.csv", index=False)
    print(f"  → {len(batting)} batting records saved to data/raw/batting.csv")

    print("Generating bowling data...")
    bowling = generate_bowling(matches)
    bowling.to_csv("data/raw/bowling.csv", index=False)
    print(f"  → {len(bowling)} bowling records saved to data/raw/bowling.csv")

    print("\nData generation complete!")
