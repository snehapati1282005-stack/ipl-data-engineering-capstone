"""
Task 6  — SQL Basics: SELECT, WHERE, GROUP BY, ORDER BY
Task 7  — Advanced SQL: Joins, subqueries, window functions
Task 8  — OLTP vs OLAP concepts demonstrated via queries
"""

import sqlite3
import pandas as pd

DB_PATH = "data/warehouse/ipl_warehouse.db"


def run_query(conn, title, sql):
    print(f"\n{'='*60}")
    print(f"📊 {title}")
    print('='*60)
    df = pd.read_sql_query(sql, conn)
    print(df.to_string(index=False))
    return df


def run_all_analytics():
    conn = sqlite3.connect(DB_PATH)

    # ── Task 6: Basic SQL ──────────────────────────────────────

    run_query(conn, "Top 10 Highest Scoring Teams (Basic SELECT + GROUP BY + ORDER BY)","""
        SELECT winner AS team,
               COUNT(*) AS wins
        FROM   fact_matches
        WHERE  winner IS NOT NULL
        GROUP  BY winner
        ORDER  BY wins DESC
        LIMIT  10
    """)

    run_query(conn, "Matches played at each venue (GROUP BY + ORDER BY)","""
        SELECT venue,
               COUNT(*) AS total_matches,
               AVG(team1_score + team2_score) AS avg_combined_score
        FROM   fact_matches
        GROUP  BY venue
        ORDER  BY total_matches DESC
    """)

    run_query(conn, "Season-wise match count (WHERE + GROUP BY)","""
        SELECT year AS season,
               COUNT(*) AS matches_played
        FROM   fact_matches
        WHERE  year >= 2008
        GROUP  BY year
        ORDER  BY year
    """)

    # ── Task 7: Advanced SQL ───────────────────────────────────

    run_query(conn, "Top Batsmen with >500 runs (Subquery + Aggregation)","""
        SELECT player,
               total_runs,
               matches,
               ROUND(total_runs * 1.0 / matches, 2) AS runs_per_match
        FROM   agg_player_batting
        WHERE  total_runs > (
                   SELECT AVG(total_runs) FROM agg_player_batting
               )
        ORDER  BY total_runs DESC
        LIMIT  15
    """)

    run_query(conn, "Window Function: Rank teams by wins per season","""
        SELECT year,
               winner                                               AS team,
               COUNT(*)                                             AS wins,
               RANK() OVER (PARTITION BY year ORDER BY COUNT(*) DESC) AS rank_in_season
        FROM   fact_matches
        GROUP  BY year, winner
        ORDER  BY year, rank_in_season
        LIMIT  30
    """)

    run_query(conn, "Running total of wins per team (Cumulative window function)","""
        SELECT winner AS team,
               year,
               COUNT(*)                                         AS season_wins,
               SUM(COUNT(*)) OVER (PARTITION BY winner ORDER BY year) AS cumulative_wins
        FROM   fact_matches
        GROUP  BY winner, year
        ORDER  BY winner, year
        LIMIT  40
    """)

    run_query(conn, "Toss advantage analysis (JOIN-style aggregation)","""
        SELECT toss_decision,
               COUNT(*)                                                AS total_matches,
               SUM(won_by_batting_first)                              AS won_after_toss_bat,
               ROUND(SUM(won_by_batting_first)*100.0/COUNT(*), 2)    AS win_pct
        FROM   fact_matches
        GROUP  BY toss_decision
    """)

    run_query(conn, "Best bowling economy (min 10 matches) - Advanced filter","""
        SELECT bowler,
               total_wickets,
               matches,
               avg_economy
        FROM   agg_player_bowling
        WHERE  matches >= 10
        ORDER  BY avg_economy ASC
        LIMIT  10
    """)

    conn.close()
    print("\n✅ All analytics queries executed successfully.")


if __name__ == "__main__":
    run_all_analytics()
