"""
Task 10 — ETL Pipeline
Task 11 — Batch Ingestion from CSV to SQLite Database
Task 3  — Read/clean/merge multiple CSV files
Task 5  — Large-scale Pandas analysis with memory optimization
Task 29 — Data Quality Validation
"""

import pandas as pd
import numpy as np
import sqlite3
import os
import sys
import logging
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from modules.transformations import (
    validate_schema, validate_no_duplicates, validate_ranges,
    clean_missing, normalize_min_max,
    aggregate_team_stats, aggregate_player_batting, aggregate_player_bowling
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/etl.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

DB_PATH = "data/warehouse/ipl_warehouse.db"
PROCESSED_PATH = "data/processed"


# ─────────────────────────────────────────────
# EXTRACT
# ─────────────────────────────────────────────

def extract():
    logger.info("=== EXTRACT PHASE ===")
    # Task 3: Read multiple CSVs, use chunking for large files (Task 5 memory optimization)
    logger.info("Loading matches.csv...")
    matches = pd.read_csv("data/raw/matches.csv", parse_dates=["date"])

    logger.info("Loading batting.csv in chunks (memory optimization)...")
    chunks = []
    for chunk in pd.read_csv("data/raw/batting.csv", chunksize=50000):
        chunks.append(chunk)
    batting = pd.concat(chunks, ignore_index=True)

    logger.info("Loading bowling.csv...")
    bowling = pd.read_csv("data/raw/bowling.csv")

    logger.info(f"Extracted → matches:{len(matches)}, batting:{len(batting)}, bowling:{len(bowling)}")
    return matches, batting, bowling


# ─────────────────────────────────────────────
# TRANSFORM
# ─────────────────────────────────────────────

def transform(matches, batting, bowling):
    logger.info("=== TRANSFORM PHASE ===")

    # --- Validate schemas (Task 29)
    validate_schema(matches, ["match_id","date","team1","team2","winner","venue"], "matches")
    validate_schema(batting, ["match_id","team","player","runs","balls","strike_rate"], "batting")
    validate_schema(bowling, ["match_id","bowler","wickets","economy"], "bowling")

    # --- Clean missing values
    matches = clean_missing(matches, {"player_of_match": "Unknown"})
    batting  = clean_missing(batting,  {"strike_rate": "mean"})

    # --- Remove duplicates
    matches = validate_no_duplicates(matches, ["match_id"], "matches")
    batting  = validate_no_duplicates(batting,  ["match_id","player"], "batting")

    # --- Validate ranges (Task 29 anomaly detection)
    batting  = validate_ranges(batting,  "runs",    0, 350, "batting")
    batting  = validate_ranges(batting,  "balls",   1, 360, "batting")
    bowling  = validate_ranges(bowling,  "economy", 0,  30, "bowling")

    # --- Feature engineering
    matches["year"]  = matches["date"].dt.year
    matches["month"] = matches["date"].dt.month
    matches["won_by_batting_first"] = (
        (matches["toss_decision"] == "bat") & (matches["toss_winner"] == matches["winner"])
    ).astype(int)

    batting["boundary_runs"] = batting["fours"] * 4 + batting["sixes"] * 6
    batting["dot_balls"]     = batting["balls"] - batting["fours"] - batting["sixes"]

    # --- Normalize for ML-readiness (Task 4)
    batting = normalize_min_max(batting, ["runs", "strike_rate"])

    # --- Aggregations
    team_stats    = aggregate_team_stats(matches)
    player_bat    = aggregate_player_batting(batting)
    player_bowl   = aggregate_player_bowling(bowling)

    logger.info("Transformation complete.")
    return matches, batting, bowling, team_stats, player_bat, player_bowl


# ─────────────────────────────────────────────
# LOAD  — Data Warehouse (SQLite star schema)
# ─────────────────────────────────────────────

def load(matches, batting, bowling, team_stats, player_bat, player_bowl):
    logger.info("=== LOAD PHASE ===")
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(PROCESSED_PATH, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # --- Dimension tables (Task 9: Star Schema)
    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS dim_team (
            team_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            team_name TEXT UNIQUE NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dim_venue (
            venue_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            venue_name TEXT UNIQUE NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dim_player (
            player_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            player_name TEXT UNIQUE NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dim_date (
            date_id INTEGER PRIMARY KEY,
            date    TEXT,
            year    INTEGER,
            month   INTEGER
        );
    """)

    # Populate dimensions
    all_teams = pd.Series(
        pd.concat([matches["team1"], matches["team2"]]).unique()
    ).drop_duplicates()
    for t in all_teams:
        cursor.execute("INSERT OR IGNORE INTO dim_team(team_name) VALUES (?)", (t,))

    for v in matches["venue"].unique():
        cursor.execute("INSERT OR IGNORE INTO dim_venue(venue_name) VALUES (?)", (v,))

    all_players = pd.Series(batting["player"].unique()).drop_duplicates()
    for p in all_players:
        cursor.execute("INSERT OR IGNORE INTO dim_player(player_name) VALUES (?)", (p,))

    conn.commit()

    # --- Fact tables
    logger.info("Loading fact tables...")
    matches.to_sql("fact_matches",     conn, if_exists="replace", index=False)
    batting.to_sql("fact_batting",     conn, if_exists="replace", index=False)
    bowling.to_sql("fact_bowling",     conn, if_exists="replace", index=False)
    team_stats.to_sql("agg_team_stats",     conn, if_exists="replace", index=False)
    player_bat.to_sql("agg_player_batting", conn, if_exists="replace", index=False)
    player_bowl.to_sql("agg_player_bowling",conn, if_exists="replace", index=False)

    conn.commit()
    conn.close()

    # Also save processed CSVs
    matches.to_csv(f"{PROCESSED_PATH}/matches_clean.csv", index=False)
    team_stats.to_csv(f"{PROCESSED_PATH}/team_stats.csv",  index=False)
    player_bat.to_csv(f"{PROCESSED_PATH}/player_batting.csv", index=False)
    player_bowl.to_csv(f"{PROCESSED_PATH}/player_bowling.csv", index=False)

    logger.info(f"Data loaded into {DB_PATH}")
    logger.info(f"Processed CSVs saved to {PROCESSED_PATH}/")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def run_etl():
    start = datetime.now()
    logger.info(f"IPL ETL Pipeline started at {start}")
    matches, batting, bowling = extract()
    matches, batting, bowling, team_stats, player_bat, player_bowl = transform(matches, batting, bowling)
    load(matches, batting, bowling, team_stats, player_bat, player_bowl)
    elapsed = (datetime.now() - start).seconds
    logger.info(f"ETL complete in {elapsed}s")


if __name__ == "__main__":
    run_etl()
