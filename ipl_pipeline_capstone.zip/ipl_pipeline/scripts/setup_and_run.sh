#!/bin/bash
# ============================================================
# Task 1 — Linux + File System Task
# Structured directory setup, permissions, file movement, logging
# ============================================================

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG_FILE="$PROJECT_DIR/logs/setup.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

log() { echo "[$TIMESTAMP] $1" | tee -a "$LOG_FILE"; }

echo "============================================================"
echo " IPL Data Engineering Pipeline — Environment Setup"
echo "============================================================"

# Create structured directories
log "Creating project directory structure..."
mkdir -p "$PROJECT_DIR"/{data/{raw,processed,warehouse,archive},logs,scripts,modules,airflow/dags,dashboard,docs}

# Set permissions (Task 1: file permissions)
log "Setting permissions..."
chmod 755 "$PROJECT_DIR/scripts/"*.py  2>/dev/null || true
chmod 644 "$PROJECT_DIR/data/raw/"*.csv 2>/dev/null || true
chmod 755 "$PROJECT_DIR/logs"

# Create __init__.py files
touch "$PROJECT_DIR/modules/__init__.py"
touch "$PROJECT_DIR/scripts/__init__.py"

# Install dependencies
log "Installing Python dependencies..."
pip install pandas numpy --quiet --break-system-packages 2>/dev/null

log "Running data generation..."
cd "$PROJECT_DIR" && python scripts/generate_data.py 2>&1 | tee -a "$LOG_FILE"

log "Running ETL pipeline..."
python scripts/etl_pipeline.py 2>&1 | tee -a "$LOG_FILE"

log "Running SQL analytics..."
python scripts/sql_analytics.py 2>&1 | tee -a "$LOG_FILE"

log "Generating dashboard..."
python dashboard/dashboard.py 2>&1 | tee -a "$LOG_FILE"

# Archive old raw data (Task 1: automate file movement)
log "Archiving raw data..."
ARCHIVE_DIR="$PROJECT_DIR/data/archive/$(date '+%Y%m%d_%H%M%S')"
mkdir -p "$ARCHIVE_DIR"
cp "$PROJECT_DIR/data/raw/"*.csv "$ARCHIVE_DIR/" 2>/dev/null
log "Raw files backed up to $ARCHIVE_DIR"

log "✅ Pipeline setup and execution complete!"
echo ""
echo "📊 Dashboard: $PROJECT_DIR/dashboard/ipl_dashboard.html"
echo "🗄️  Warehouse: $PROJECT_DIR/data/warehouse/ipl_warehouse.db"
echo "📋 Logs:      $LOG_FILE"
